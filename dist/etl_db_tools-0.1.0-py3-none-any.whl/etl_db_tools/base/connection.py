
from abc import ABC
from collections.abc import Iterator

class Connection(ABC):

    def __init__(self) -> None:
        super().__init__()


    def to_string(self):
        pass

    def select_data(self, query: str) -> Iterator[list[dict]]:
        pass    
    def __print__(self):
        pass