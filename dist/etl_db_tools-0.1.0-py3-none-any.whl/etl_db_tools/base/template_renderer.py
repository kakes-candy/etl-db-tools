from jinja2 import Environment, FileSystemLoader
from etl_db_tools.sqlservertools import sqlservertools as sql




def sql_render(template:str, data:sql.Table) -> str:

    env = Environment(
        loader=FileSystemLoader("etl_db_tools/templates")
    )

    template = env.get_template(template)

    return template.render(table = data)