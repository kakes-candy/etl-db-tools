from etl_db_tools.base.connection import Connection
from etl_db_tools.base.schema import BaseTable, Column
from collections.abc import Iterator
import pyodbc
import warnings



class Column(Column):

    def __init__(self, name: str, type: str, nullable: bool, 
                 length: int = None, precission: int = None, 
                 scale=None, default=None) -> None:
        super().__init__(name, type, nullable, length, precission, scale, default)
    
    def quoted_name(self):
        return(f'[{self.name}]')

class Table(BaseTable):

    def __init__(self, name, columns: list[Column] = None) -> None:
        super().__init__(name, columns)
        
   
    @classmethod
    def from_connection(cls, connection: Connection, table_name:str):
        querystring = f"""
                select 
                c.TABLE_NAME
                ,c.COLUMN_NAME
                ,c.DATA_TYPE
                ,convert(bit, iif(c.IS_NULLABLE = 'YES' , 1, 0)) as IS_NULLABLE
                ,c.CHARACTER_MAXIMUM_LENGTH
                ,c.NUMERIC_PRECISION
                ,c.NUMERIC_SCALE
                ,c.COLUMN_DEFAULT
                from information_schema.columns as c 
                where CONCAT(c.TABLE_SCHEMA, '.', c.table_name) = '{table_name}'
                order by c.ORDINAL_POSITION"""    
        
        res_gen =connection.select_data(querystring)
            
        columns =[]
        for column in res_gen:
            c = Column(name=column.get('COLUMN_NAME'),
                    type=column.get('DATA_TYPE'),
                    nullable=column.get('IS_NULLABLE'),
                    length=column.get('CHARACTER_MAXIMUM_LENGTH'),
                    precission=column.get('NUMERIC_PRECISION'),
                    scale=column.get('NUMERIC_SCALE'),
                    default=column.get('COLUMN_DEFAULT', 'DeNada'))

            columns.append(c)


        # make instance from output column definition
        return cls(name = table_name, columns = columns) 




class SQLserverconnection(Connection):
    def __init__(self, driver: str, server: str, database:str, **kwargs) -> None:
        self.driver = driver
        self.server = server
        self.database = database
        self.other_params = kwargs

    def to_string(self):

        basic_cnxn = f'DRIVER={{{self.driver}}};SERVER={self.server};DATABASE={self.database}'
        # make a list and add further elements
        cnxn_ls = [basic_cnxn, ]
        for k, v in self.other_params.items():
            cnxn_ls.append(f'{k}={v}')

        # make the final string
        final_cnxn = ';'.join(cnxn_ls)
        return final_cnxn
    
    def select_data(self, query: str) -> Iterator[list[dict]]:

        with pyodbc.connect(self.to_string()) as conn:
            cursor = conn.cursor()
            cursor.execute(query)
            columns = [column[0] for column in cursor.description]
            while True:
                results = cursor.fetchmany(5000)
                if not results:
                    break                
                for result in results:
                    yield dict(zip(columns, result))
                else:
                    break
        conn.close()    

    def if_exists(self, table_name):

        query = f"""
        select s.[name], object_id, sc.name
        from sys.tables as s
        inner join sys.schemas as sc
        on s.schema_id = sc.schema_id
        where concat(sc.name, '.', s.name) = '{table_name}'
        and s.[type] = 'U'"""

        res = self.select_data(query)
        if len(list(res)) > 0:
            return True
        elif len(list(res)) == 0:
            return False     

    def drop_table(self, table_name:str) -> None:
        q = f'drop table if exists {table_name} ;'

        with pyodbc.connect(self.to_string()) as conn:
            cursor = conn.cursor()
            cursor.execute(q)
            cursor.commit()
        conn.close()

    def create_table(self, table: Table, drop_if_exists:bool):
 
        if self.if_exists(table_name=table.name) and drop_if_exists is False:
            warnings.warn("can't create table because it allready exists and drop_if_exists is False")
            return
        elif self.if_exists(table_name=table.name) and drop_if_exists is True:
            self.drop_table(table_name=table.name)
        else:
            q = table.create_table_statement()       
            with pyodbc.connect(self.to_string()) as conn:
                cursor = conn.cursor()
                cursor.execute(q)
                cursor.commit()
            conn.close()        


    
    def sql_insert_dictionary(self, table: Table, data:list[dict]):
        
        # All keys must be a column name, only colums with keys in the data are relevant
        colums_table = [x.name for x in table.columns]
        data_columns = data[0].keys()
        for c in data_columns:
            if c not in colums_table:
                raise KeyError(f'data column {c} does not match any column in the table object')
      
        insert_colums = [c for c in colums_table if c in data_columns]
        columnlist = [x.quoted_name() for x in table.columns if x in insert_colums]


        """ 
        columnlist = [x.quoted_name() for x in table.columns]

        columnlist_joined = ', '.join(columnlist)
        value_arguments = ', '.join(len(columnlist)*'?')
        sql_insert_into_statement = f'insert into {table.name} ({columnlist_joined}) values ({value_arguments})'
    
        # Remove all items from dict where key does not match any column name

        cleaned_data = []
        for row in data:
            rowlist = [row.get() for ]
            for column in [x.name for x in table.columns]:
                rowlist.append(row.get(column))
            cleaned_data.append(rowlist)

        with pyodbc.connect(self.connection) as conn:
            cursor = conn.cursor()
            cursor.fast_executemany = True
            cursor.executemany(sql_insert_into_statement, cleaned_data)
        conn.close() """


    def sql_insert_list(self, data):
 
        columnlist = [self.safe_column_name(x['column_name']) for x in self.tableschema]

        columnlist_joined = ', '.join(columnlist)
        value_arguments = ', '.join(len(columnlist)*'?')
        sql_insert_into_statement = f'insert into {self.target_schema}.{self.target_tablename} ({columnlist_joined}) values ({value_arguments})'


        with pyodbc.connect(self.connection) as conn:
            cursor = conn.cursor()
            cursor.fast_executemany = True
            cursor.executemany(sql_insert_into_statement, data)
        conn.close()
